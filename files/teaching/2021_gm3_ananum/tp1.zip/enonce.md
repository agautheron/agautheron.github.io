# Sujet TP1

Je suppose que vous avez suivi le TP0 de prise en main de python. Nous travaillerons donc dans le repertoire **TP_ANANUM/** avec l'environement virtuel python **.venv** activé: 

```
source .venv/bin/activate
python test_config.py
```

- Téléchargez et décompressez l'archive tp1.zip présente sur moodle. 

## Algorithme de descente et de remontée

Dans le repertoire TP_ANANUM/ importer le fichier **resolution.py**. Executez ce fichier depuis le terminal avec la commande suivante: 

```
python resolution.py
```
Ouvrez le fichier et modifiez les lignes indiquées. Exécutez le fichier jusqu'à ce que l'éxécution se éroule sans problèmes. 

## Algorithme de Gauss
Importez dans le dossier TP_ANANUM/ le fichier **decomposition.py**. Ouvrez et complétez l'implémentation de l'algorithme de Gauss. A l'éxécution, observez la forme de la matrice A à chaque itération.

## Bonus
Si vous avez fini importez le module time de python et ajoutez les instructions suivantes: 

``` 
import time
start = time.time()
U, new_b = gauss(A, b)
x = remontee(U, new_b)
end = time.time()
print("Methode de Gauss : " + str(end-start) + " s. error : " + str(np.linalg.norm(x-sol)))
```
Faites plusieurs tests en augmentant la taille N de la matrice A pour voir l'influence de ce paramètre sur le temps d'éxécution. 
