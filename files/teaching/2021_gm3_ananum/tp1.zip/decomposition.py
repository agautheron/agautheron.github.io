# coding : utf-8
import numpy as np
from resolution import remontee

def gauss(A, b):
    nx, ny = A.shape
    Ac = A.copy()
    bc = b.copy()
    
    # /!\ Dans l'algorithme on utilisera les variables Ac et bc.
    
    for k in range(nx-1):
        print("Etape " + str(k+1) + ":\n" + str(Ac) + "\n")
        for i in range(k+1, nx):
            # Compléter ici
            # Compléter ici
            for j in range(k, nx):
                # Compléter ici à la place de l'instruction "pass"
                pass
    
    print("Etape " + str(nx) + ":\n" + str(Ac) + "\n")
    return Ac, bc

if __name__ == "__main__":
    N = 4
    
    A   = np.random.randint(low=-10, high=10, size=(N, N)).astype(np.double)
    sol = np.random.randint(low=-10, high=10, size=(N)).astype(np.double)
    
    b = A @ sol
    
    U, new_b = gauss(A, b)
    x = remontee(U, new_b)
    
    if np.linalg.norm(x-sol) < 10**(-9):
        print("Bravo vous avez correctement implémenter la méthode de Gauss")
    else: 
        print("Algo de Gauss incorrect")
    
