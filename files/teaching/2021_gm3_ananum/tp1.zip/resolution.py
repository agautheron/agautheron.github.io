import numpy as np


'''
Solve Linear system L*y = b where L is a lower triangular matrix
'''
def descente(L, b): 
    nx, ny = L.shape
    y = np.zeros(shape=(nx,), dtype=np.double)
    
    for i in range(nx):
        print("Etape " + str(i+1) + "\n" + str(y) + "\n")
        # Compléter ici        
        for j in range(0, i):
            # compléter ici à la place de l'instruction "pass"
            pass
        # compléter ici
        
    return y

'''
Solve Linear system U*x = y where U is an upper triangular matrix 
'''
def remontee(U, y):
    nx, ny = U.shape
    x = np.zeros(shape=(nx,), dtype=np.double)
    
    # Ecrire l'algorithme de remontée ici
     
    return x

if __name__ == "__main__":
    N = 4
    A = np.random.rand(N, N)
    
    L = np.tril(A)
    U = np.triu(A)
    
    sol_y = np.random.rand(N)
    b_y = L @ sol_y
    
    sol_x = np.random.rand(N)
    b_x = U @ sol_x
    
    y = descente(L, b_y)
    if np.linalg.norm(y-sol_y) < 10**(-9):
        print("Bravo vous avez réussi l'algorthme de descente")
    else: 
        print("Algo de descente incorrect")
    
    x = remontee(U, b_x)
    if np.linalg.norm(x-sol_x) < 10**(-9):
        print("Bravo vous avez réussi l'algorthme de remontée")
    else:
        print("Algo de remontée incorrect")
        
    

