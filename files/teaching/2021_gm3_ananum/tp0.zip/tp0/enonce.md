# Sujet TP0

TP de prise en main de Python. 

Les instructions sont données  pour un système UNIX, pour Windows et Mac demander à internet. Avant le  TP je vous demande de procéder aux étapes suivantes sur votre machine  personnelle ou sur les machines des salles de TP GM. 

Pour ceux qui veulent travailler sur leur machine personnelle: exécutez dans un terminal la commande suivante qui installe le packet virtualenv: 

```bash
sudo apt install python3-virtualenv
```

Pour tous: 

1. Créer un dossier pour les tp : TP_ANANUM/
2. Dans ce dossier, ouvrez un terminal et entrez la commande suivante qui créé un environnement python virtuel : **virtualenv .venv -p python3** 
3. Entrez la commande suivante pour activer l'environnement : **source .venv/bin/activate**
4. Téléchargez l'archive TP0.zip, décompressez là et enregistrez dans le dossier  TP_ANANUM/ les fichiers test_config.py et prise_en_main.py
5. Exécutez le fichier test_config.py avec la commande : **python test_config.py**
6. Résolvez les différents messages en installant les librairies requises. 
7. Ouvrez et éditez le fichier prise_en_main.py pour lui faire faire ce qui est demandé. 
8. En ayant gardé le même terminal que celui qui a activé l'environnement virtuel, exécutez le fichier avec la commande '**python prise_en_main.py**' 

Quand le programme est bon, vous êtes prêt pour les TPs. 