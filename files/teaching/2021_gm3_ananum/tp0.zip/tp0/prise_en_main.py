#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np

## Exercice 1: Ecrivez une boucle qui imprime les entiers de 0 à 13
print("Exercice 1: Ecrivez une boucle qui imprime les entiers de 0 à 13\n")



## Exercice 2: Ecrivez une boucle qui imprime les entiers de -7 à 3
print("Exercice 2: Ecrivez une boucle qui imprime les entiers de -7 à 3\n")




## Exercice 3: Déclarez une matrice de zeros A de taille 5x5
print("Exercice 3: Déclarez une matrice de zeros A de taille 5x5\n")



## Exercice 4: A l'aide de deux boucles imbriquées remplissez A avec les coeefficients a_{ij} = i+j, et affichez A
print("Exercice 4: A l'aide de deux boucles imbriquées remplissez A avec les coeefficients a_{ij} = i+j, et affichez A\n")


## Exercice 5: Ecrivez une fonction print_mat(A) qui prend une matrice en entrée et qui affiche la matrice A quand on l'apelle. 
print("Exercice 5: Ecrivez une fonction print_mat(A) qui prend une matrice en entrée et qui affiche la matrice A quand on l'apelle. \n")




