#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("Bienvenue dans ce programme de test de la configuration python.\n")
ok=0

try:
	import numpy as np
except ModuleNotFoundError as e: 
	ok=1
	print(e)
	print("La librairie NumPy n'est pas installée.\nUtiliser 'pip install numpy'\n\n")
	

try:
	import matplotlib as plt
except ModuleNotFoundError as e: 
	ok=1
	print(e)
	print("La librairie Matplotlib n'est pas installée.\nUtiliser 'pip install matplotlib'\n\n")	
	
try:
	import scipy
except ModuleNotFoundError as e:
	ok=1 
	print(e)
	print("La librairie SciPy n'est pas installée.\nUtiliser 'pip install scipy'\n\n")	
	
if ok: 
	print("Il y a des erreurs non résolues.")
else: 
	print("La configration est bonne, vous êtes prêt pour les exercices dans le fichiers prise_en_main.py")
