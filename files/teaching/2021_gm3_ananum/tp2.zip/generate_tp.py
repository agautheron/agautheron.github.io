# coding : utf-8
import os
import numpy as np
import numpy.polynomial.polynomial as nppol
import matplotlib.pyplot as plt

# Script pour générer son sujet de TP
# Ne pas modifier !

# Paramètres
d   = 2     # degré du polynôme
N   = 150   # nombre de données
eps = 0.5   # bruit
P   = np.random.randint(low=-10, high=10, size=(d+1,)).astype(np.double) # polynôme solution

# Générer les données. 
x = np.sort(2 * np.random.rand(N) - 1)
y = (nppol.polyval(x, P) + eps * np.random.randn(N))

# Sauvegarder les données
if not os.path.exists("./data/"):
    os.mkdir("./data/")

with open("data/tp_data.txt", 'w') as f: 
    f.write(str(N) + " " + str(d))

with open("data/tp_data_x.txt", 'w') as f: 
    for i in range(N):
        f.write(str(x[i]) + "\n")

with open("data/tp_data_y.txt", 'w') as f: 
    for i in range(N):
        f.write(str(y[i]) + "\n")

with open("data/tp_sol.txt", 'w') as f: 
    f.write(str(P))

plt.plot(x, y, 'ro')
plt.legend(['Données (x_i,y_i)'])
plt.xlabel('x')
plt.ylabel('y')
plt.title('Données Client')
plt.savefig('data/donnees_clients.png')

# Afficher que la génération est ok 
print("Les données du TP ont été générées sans erreurs dans le dossier data/.")