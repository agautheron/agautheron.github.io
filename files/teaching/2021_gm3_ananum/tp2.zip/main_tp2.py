# coding : utf-8
import numpy as np
import numpy.polynomial.polynomial as nppol
import matplotlib.pyplot as plt

'''
Charge les données du TP. 
Ne pas modifier ! 
'''
def load_TP(): 
    with open('data/tp_data.txt') as f:
        N, d = [int(x) for x in next(f).split()]
    
    with open('data/tp_data_x.txt') as f:
        x = []
        for line in f: # read rest of lines
            data = line.split()
            x.append(np.double(data[0]))

    with open('data/tp_data_y.txt') as f:
        y = []
        for line in f: # read rest of lines
            data = line.split()
            y.append(np.double(data[0]))

    with open('./data/tp_sol.txt') as f: 
        line = f.read()
        P = []
        for i in line.split('[')[1].split(']')[0].split():
            P.append(np.double(i))

    return N, d, x, y, P

'''
Solve Linear system U*x = y where U is an upper triangular matrix of size (Nx, Ny) (non necessarily square) but Nx > Ny
Ne pas modifier !
'''
def remontee(U, y):
    ny = U.shape[1]
    x = np.zeros(shape=(ny,), dtype=np.double)
    
    for i in range(ny-1, -1, -1):
        x[i] = y[i]
        for j in range(i+1, ny):
            x[i] = x[i] - U[i,j] * x[j]
        x[i] = x[i] / U[i,i]
     
    return x

'''
Construct matrix A and right hand side vector b
'''
def construct_Ab(N, d, x, y):
    A = np.zeros(shape=(N, d+1), dtype=np.double)
    b = np.zeros(shape=(N), dtype=np.double)
    
    # Compléter ici
    
    return A, b

def_orth_q = 0 # variable globale pour sauvegarder le défaut d'othogonalité de la matrice Q

'''
Compute QR decomposition of a matrix A of size Nx x Ny (Nx > Ny) with Gram-Schmidt algorithm
Q is orthogonal of size Nx x Ny
R is upper triangular of size Ny x Ny
'''
def QR_GS(A):
    nx, ny = A.shape
    R = np.zeros(shape=(ny, ny), dtype=np.double)
    Q = np.zeros(shape=(nx, ny), dtype=np.double)
    
    # Compléter ici

    global def_orth_q
    def_orth_q = np.linalg.norm(np.eye(ny) - np.matmul(np.transpose(Q), Q))
    print("La matrice Q donnée par la procédure de G-S est orthogonale à ||Id_{d+1} - Q^t * Q|| = " + str(def_orth_q) + " près.") 
    return Q, R

'''
Solve least square problem min_x ||Ax - b||^2 via QR décomposition of A
'''
def solve_lsq(A, b):
    nx, ny = A.shape 
    sol = np.zeros(shape=(ny), dtype=np.double)

    # Compléter ici
    
    return sol


'''
Main fonction 
Ne pas modifier ! Sauf la valeur de d quand on vous le demande. 
'''
if __name__== "__main__":
    # On charge les données du TP générées à l'étape précédente. 
    N, deg, x, y, P = load_TP()
    d = 3

    # On construit la matrice A et le vecteur b
    A, b = construct_Ab(N, d, x, y)

    # On résoud par l'algorithme de remontée le problème des moindres carrées réécrit pour Q et R
    sol_P = solve_lsq(A, b)
    print(def_orth_q)
    # On calcul l'erreur comise entre la solution calculée et al solution exacte
    m = np.mean(y)
    err = 100 * (1 - np.linalg.norm(nppol.polyval(x, sol_P) - y)**2 / np.linalg.norm(y - np.mean(y))**2)
    print('{:<22}{:<20}'.format('Variance expliquée:', str(round(err, 2))+' %'))

    txt_1 = str(round(P[0])) + ' + ' + str(round(P[1])) + '.X'
    if (1 < len(P)) and (not round(P[1]) == 0):
        txt_1 += ' + ' + str(round(P[1])) + '.X'
    for i in range(2,deg+1):
        if not round(P[i]) == 0:
            txt_1 += ' + ' + str(round(P[i])) + '.X^'+str(i)
    print('{:<22}{:<20}'.format('Polynôme exact: ', txt_1))

    txt_2 = str(round(sol_P[0], 2))
    if (1 < len(sol_P)) and (not round(sol_P[1], 2)) == 0:
        txt_2 += ' + ' + str(round(sol_P[1], 2)) + '.X'
    for i in range(2, d+1):
        if not round(sol_P[i],2) == 0:
            txt_2 += ' + ' + str(round(sol_P[i],2)) + '.X^'+str(i)
    print('{:<22}{:<20}'.format('Polynôme approché: ', txt_2))

    plt.plot(x, y, 'ro')
    plt.plot(np.sort(x), nppol.polyval(np.sort(x),P), 'b-')
    plt.plot(np.sort(x), nppol.polyval(np.sort(x),sol_P), 'k-')
    plt.plot([], [], ' ') # Create empty plot with blank marker containing the extra label
    plt.plot([], [], ' ') # Create empty plot with blank marker containing the extra label
    if (d <= 5): 
        plt.legend(['Données (x_i,y_i)',str('Solution exacte: ' + txt_1), str('Solution approchée: ' + txt_2), 'Variance expliquée: ' + str(round(err,2))+' %', "Défaut d'orthogonalité de Q: {:0.2e}".format(def_orth_q)])
    else: 
        plt.legend(['Données (x_i,y_i)', 'Solution exacte', 'Solution approchée de degré d = ' + str(d), 'Variance expliquée: ' + str(round(err,2))+' %', "Défaut d'orthogonalité de Q: {:0.2e}".format(def_orth_q)])
    plt.xlabel('x')
    plt.ylabel('y')
    plt.title('Résultats')
    plt.show()