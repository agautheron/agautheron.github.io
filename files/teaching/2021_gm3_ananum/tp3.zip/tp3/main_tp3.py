import numpy as np 
import matplotlib.pyplot as plt

"""
Function to solve a linear system Ax=b with conjugate gradient method
Input:
A : is a square matrix of dimension N x N, must be symmetric positive definite
b : is a vector of dimension N
Output: 
x : approximation of the solution 
err : list of the residuals norms computed at each step of the iteration 
"""
def conjugate_gradient(A, b, eps = 1e-5): 
    N   = b.shape[0]
    err = np.ones(shape=(N,))
    
    # Modify those instructions here
    x = np.zeros((N,))
    r = np.ones((N,))
    p = np.ones((N,))
    
    for k in range(N): 
        err[k] = np.sqrt(np.inner(r,r))
        
        if (err[k] < eps):
            break
        
        # Complete instructions here        
    
    return x, err[0:k]

if __name__=="__main__":
    # Dimension of the problem
    N = 500
    
    # Matrix A of the linear system.
    # We use here a random positive symmetric matrix and shift its diagonal to make it well conditionned.
    A = np.random.normal(0., 1., (N,N))
    A = np.matmul(A, A.transpose()) + np.eye(N)

    # Right hand side of the linear system. We use here a random vector.
    b = np.random.normal(0., 1., (N,))

    # Call conjugate gradient algorithm
    x, err = conjugate_gradient(A, b)

    # Plot error evolution
    plt.plot(err, 'b-')
    plt.yscale("log")
    plt.xlabel("Iteration k")
    plt.ylabel("log-norm of residuals")
    plt.title("Evolution of the log norm of the residual: $\log (||r^k||)$")
    plt.show()