import numpy as np 

def grad(f): 
    N = f.shape[0] # f must be square

    idx = [N-1]
    for i in range(N-1):
        idx.append(i)

    return np.dstack([f-f[idx,:], f - f[:,idx]])

def div(g): 
    N = g.shape[0] # g must be square

    idx = [i for i in range(1,N)]
    idx.append(0)

    return g[idx, :, 0] - g[:, :, 0] + g[:, idx, 1] - g[:, :, 1]

def laplacian(f): 
    return div(grad(f))