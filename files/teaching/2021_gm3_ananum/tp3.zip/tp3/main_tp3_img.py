import numpy as np 
import matplotlib.pyplot as plt
import matplotlib.image as img
from utils import *

# Import Image 
I = np.array(img.imread("lena.jpg")).astype(np.double)
I = I / np.max(I)
N = I.shape[0]

## Creating degrading mask of image 
M = np.random.rand(N,N) > .7
# Optionnal additional degradation
"""
w = 100
m = 70
M[m:m+w,m:m+w] = 0.
"""

def mask(x): 
    return np.multiply(M,x)

# Inpainting parameter
l = 0.01

def linear_operator(x):
    x   = x.reshape(N,N)
    # Complete here
    res = np.zeros((N,N))
    return res.reshape(-1)

def conjugate_gradient(A, b, eps = 1e-5): 
    N   = b.shape[0]
    err = np.ones(shape=(N,))
    
    # Modify those instructions here
    x = np.zeros((N,))
    r = np.ones((N,))
    p = np.ones((N,))
    
    for k in range(N): 
        err[k] = np.sqrt(np.inner(r,r))
        
        if (err[k] < eps):
            break
        
        # Complete instructions here        
    
    return x, err[0:k]

if __name__=="__main__":

    # Display original image
    plt.axis('off')
    plt.imshow(I, cmap='gray')
    plt.title("Original Image")
    plt.show()
    
    # Test Grad of image 
    """
    g = grad(I)
    fig, ax = plt.subplots(1,2)
    plt.title("Gradient of image")
    ax[0].imshow(g[:,:,0], cmap='gray')
    ax[1].imshow(g[:,:,1], cmap='gray')
    ax[0].title.set_text('$d/dx$')
    ax[1].title.set_text('$d/dy$')
    ax[0].axis('off')
    ax[1].axis('off')
    plt.show()
    """

    # Test Laplacian image
    """
    L = laplacian(I)
    plt.axis('off')
    plt.imshow(L, cmap='gray')
    plt.title("Laplacian of image: $\Delta (x)$")
    plt.show()
    """
    
    # Degradation image
    degraded_I = mask(I)

    # Display degraded image
    plt.axis('off')
    plt.imshow(degraded_I, cmap='gray')
    plt.title("Degraded image")
    plt.show()
    
    # Preparation inpainting    
    b = degraded_I.reshape(-1)

    # Call conjugate gradient method
    intpaint, err = conjugate_gradient(linear_operator, b)
    intpaint = intpaint.reshape(N,N)

    # Display conjugate gradient residuals norm evolution
    plt.plot(err, 'b-')
    plt.yscale("log")
    plt.xlabel("Iteration k")
    plt.ylabel("log-norm of residuals")
    plt.title("Evolution of the log norm of the residual: $\log (||r^k||)$")
    plt.show()

    # display reconstructed image
    plt.axis('off')
    plt.imshow(intpaint, cmap='gray')
    plt.title("Reconstructed image")
    plt.show()